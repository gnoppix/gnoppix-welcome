<div align="center">
  <h1>CachyOS Welcome</h1>
  <p>
    <strong>Welcome screen for CachyOS written in Rust</strong>
  </p>
  <p>

[![Dependency Status](https://deps.rs/repo/github/cachyos/cachyos-welcome/status.svg)](https://deps.rs/repo/github/cachyos/cachyos-welcome)
<br />
[![CI](https://github.com/cachyos/cachyos-welcome/actions/workflows/rust.yml/badge.svg)](https://github.com/cachyos/cachyos-welcome/actions/workflows/rust.yml)

  </p>
</div>
